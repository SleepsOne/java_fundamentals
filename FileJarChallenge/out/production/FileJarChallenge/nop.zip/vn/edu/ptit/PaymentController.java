package vn.edu.ptit;

import java.util.ArrayList;
import java.util.Scanner;

public class PaymentController {
    private Invoice invoice;
    private static Scanner sc = new Scanner(System.in);

    public PaymentController(){
//        String msv, hoten, soMonHoc,maMon, tenMon, soTinchi, SoQD, tenQD, donGia;
        invoice = new Invoice();
        invoice.setSt(new Student());
        invoice.setAlSubject(new ArrayList<>());
        invoice.setRule(new Rule());
//        invoice
//        invoice
        invoice.getSt().setCode(sc.nextLine());
        invoice.getSt().setName(sc.nextLine());
        int soMonHoc_int = Integer.parseInt(sc.nextLine());
        ArrayList <Subject> tmp = new ArrayList<>();
        for (int i  = 0; i < soMonHoc_int; i++){
            tmp.add(new Subject(sc.nextLine(), sc.nextLine(), Integer.parseInt(sc.nextLine())));
        }
        invoice.setAlSubject(tmp);
        invoice.getRule().setCode(sc.nextLine());
        invoice.getRule().setName(sc.nextLine());
        invoice.getRule().setCreditPrice(Double.parseDouble(sc.nextLine()));
        invoice.setAmount(TotalCal());
    }
    public double TotalCal(){
        double sum = 0;
        double gia = invoice.getRule().getCreditPrice();
        for (Subject x : invoice.getAlSubject()){
            sum += x.getCredit() * gia;

        }
        return sum;

    }

    public PaymentController(Invoice invoice) {
        this.invoice = invoice;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
