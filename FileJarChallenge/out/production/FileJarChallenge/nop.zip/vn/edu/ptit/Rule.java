//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package vn.edu.ptit;

import java.util.Scanner;

public class Rule {
    private String code;
    private String name;
    private double creditPrice;


    public Rule(String code, String name, double creditPrice) {
        this.code = code;
        this.name = name;
        this.creditPrice = creditPrice;
    }

    public Rule() {
    }

    public String getCode() {
        return this.code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCreditPrice() {
        return this.creditPrice;
    }

    public void setCreditPrice(double creditPrice) {
        this.creditPrice = creditPrice;
    }
}
