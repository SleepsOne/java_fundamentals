/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package run;

/**
 *
 * @author HP
 */
public class Main {
    public static void main(String[] args) {
        TapChi t=new TapChi("KHCNTT TT", 250, "10/2023");
        t.setMa();
        System.out.println(t);
        Sach s=new Sach("LT HDT", "Nguyen manh Son", "giao duc", 220, 1000);
        s.setMa();
        System.out.println(s);
    }
    
}
