/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package subnew;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author HP
 */
public class SubNew {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, ClassNotFoundException, IOException {
        // TODO code application logic here

        List<String> list1 = IOFile.read("DATA.in");
        String s = "";
        for (String x : list1) {
            s += x.toLowerCase() + " ";
        }
//        s = s.substring(0, s.length());
        String res = "";
        for (char c : s.toCharArray()) {
            if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')) {
                res += c;

            } else {
                res += ' ';
            }
        }
        String[] list = res.trim().split("\\s+");
        Map<String, Integer> mp = new TreeMap<>();
        for (String x : list) {
            mp.put(x, mp.getOrDefault(x, 0) + 1);
        }
        List<Map.Entry<String, Integer>> ans = new ArrayList<>(mp.entrySet());
        ans.sort((a, b) -> {
            if (a.getValue().equals(b.getValue())) {
                return a.getKey().compareTo(b.getKey());
            }
            return b.getValue().compareTo(a.getValue());
        });
        System.out.println("""
                           Ghi ra theo yêu cầu đề bài, mỗi từ trên một dòng đi kèm số lần xuất hiện. Ví dụ:
                           """);
        for (Map.Entry<String, Integer> x : ans) {
            System.out.println(x.getKey() + " " + x.getValue());
        }

    }

}
