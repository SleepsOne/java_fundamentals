/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package subnew;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author HP
 */
public class SubNew {

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
//       ObjectInputStream inp = new ObjectInputStream(new FileInputStream("DATA.in"));
        ArrayList<String> a1 = IOFile.read("DATA.in");
        ArrayList<String> token = new ArrayList<>();
        
        
        for (String i : a1)
        {
            String s = i.trim().replaceAll("\\s+", " ").toLowerCase();
            String tmp = "";
            for(int j = 0; j < s.length(); ++j)
            {
                if((s.charAt(j) < 'a' || s.charAt(j) > 'z') && (s.charAt(j) < '0' || s.charAt(j) > '9'))
                    tmp += ' ';
                else tmp += s.charAt(j);
            }
            tmp = tmp.trim().replaceAll("\\s+", " ");
            token.addAll(Arrays.asList(tmp.split(" ")));
        }
//        s = s.substring(0, s.length());
//        String res = "";

//        String[] list = res.trim().split("\\s+");
        Map<String, Integer> mp = new TreeMap<>();
        for (String x : token) {
            mp.put(x, mp.getOrDefault(x, 0) + 1);
        }
        //dung
        List<Map.Entry<String, Integer>> ans = new ArrayList<>(mp.entrySet());
        ans.sort((a, b) -> {
            if (a.getValue().equals(b.getValue())) {
                return a.getKey().compareTo(b.getKey());
            }
            return b.getValue().compareTo(a.getValue());
        });
//        System.out.println("Ghi ra theo yêu cầu đề bài, mỗi từ trên một dòng đi kèm số lần xuất hiện. Ví dụ:" + "\n");

        for (Map.Entry<String, Integer> x : ans) {
            System.out.println(x.getKey() + " " + x.getValue());
        }

    }

}
